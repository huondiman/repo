var localizedStrings = new Object;

localizedStrings["Loading Next Page..."] = "Loading Next Page...";
localizedStrings["Page %@"] = "Page %@";
localizedStrings["Page %@ of %@"] = "Page %@ of %@";
localizedStrings["Connect to the Internet to view remaining pages."] = "Connect to the Internet to view remaining pages.";

